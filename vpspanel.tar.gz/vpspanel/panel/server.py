import asyncio, hashlib, hmac, json, os, secrets, sqlite3, subprocess, time
from pathlib import Path
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Request, Depends
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBasic, HTTPBasicCredentials

BASE = Path(__file__).resolve().parent
DB = BASE / "panel.db"
TOKEN = os.getenv("PANEL_ADMIN_TOKEN", "change-me")
security = HTTPBasic()
connections = {}
pending = {}

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS nodes(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,token TEXT UNIQUE,info TEXT NOT NULL DEFAULT '{}',status TEXT NOT NULL DEFAULT 'offline',last_seen INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS vps(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,node_id INTEGER,kind TEXT NOT NULL DEFAULT 'machine',domain TEXT DEFAULT '', FOREIGN KEY(node_id) REFERENCES nodes(id));
    CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY AUTOINCREMENT,created INTEGER,action TEXT,actor TEXT,target TEXT,detail TEXT);
    ''')
    c.commit(); c.close()

def auth(credentials: HTTPBasicCredentials = Depends(security)):
    expected = os.getenv("PANEL_ADMIN_PASSWORD", "admin123")
    if not hmac.compare_digest(credentials.username, "admin") or not hmac.compare_digest(credentials.password, expected):
        raise HTTPException(401, "Invalid credentials", headers={"WWW-Authenticate":"Basic"})
    return credentials.username

def log(action, target="", detail=""):
    c=db(); c.execute("INSERT INTO logs(created,action,actor,target,detail) VALUES(?,?,?,?,?)",(int(time.time()),action,"admin",target,detail)); c.commit(); c.close()

def node_row(n):
    d=dict(n); d["info"]=json.loads(d["info"] or "{}"); return d

async def send_node(node_id, payload, timeout=30):
    ws = connections.get(node_id)
    if not ws: raise HTTPException(409, "Node is offline")
    rid=secrets.token_hex(8)
    fut=asyncio.get_running_loop().create_future(); pending[rid]=fut
    await ws.send_text(json.dumps({"id":rid,**payload}))
    try: return await asyncio.wait_for(fut, timeout)
    finally: pending.pop(rid,None)

app=FastAPI(title="VPS Panel")
app.mount("/static", StaticFiles(directory=BASE.parent / "static"), name="static")

@app.on_event("startup")
async def startup(): init_db()

@app.get("/")
async def home(): return FileResponse(BASE.parent / "static" / "index.html")

@app.get("/api/overview")
async def overview(_:str=Depends(auth)):
    c=db(); nodes=[node_row(x) for x in c.execute("SELECT * FROM nodes ORDER BY id DESC")]; vps=[dict(x) for x in c.execute("SELECT * FROM vps ORDER BY id DESC")]; logs=[dict(x) for x in c.execute("SELECT * FROM logs ORDER BY id DESC LIMIT 20")]; c.close()
    return {"nodes":nodes,"vps":vps,"logs":logs,"stats":{"nodes":len(nodes),"online":sum(x["status"]=="online" for x in nodes),"vps":len(vps)}}

@app.post("/api/nodes")
async def add_node(body:dict, _:str=Depends(auth)):
    name=str(body.get("name","")).strip()
    if not name: raise HTTPException(400,"Node name required")
    token=secrets.token_urlsafe(32)
    c=db()
    try: c.execute("INSERT INTO nodes(name,token) VALUES(?,?)",(name,token)); c.commit()
    except sqlite3.IntegrityError: c.close(); raise HTTPException(409,"Node name already exists")
    c.close(); log("node.created",name)
    return {"name":name,"token":token,"install":f"curl -fsSL http://YOUR_PANEL:8000/install-node.sh | sudo bash -s -- --panel http://YOUR_PANEL:8000 --token {token}"}

@app.get("/install-node.sh")
async def installer():
    return FileResponse(BASE.parent / "agent" / "install-node.sh", media_type="text/plain")

@app.get("/api/node/{node_id}")
async def get_node(node_id:int, _:str=Depends(auth)):
    c=db(); n=c.execute("SELECT * FROM nodes WHERE id=?",(node_id,)).fetchone(); c.close()
    if not n: raise HTTPException(404,"Node not found")
    return node_row(n)

@app.post("/api/node/{node_id}/command")
async def command(node_id:int, body:dict, _:str=Depends(auth)):
    cmd=str(body.get("command",""))
    if not cmd or len(cmd)>4000: raise HTTPException(400,"Invalid command")
    result=await send_node(node_id,{"type":"shell","command":cmd},60); log("terminal.command",str(node_id),cmd[:200]); return result

@app.get("/api/node/{node_id}/files")
async def files(node_id:int, path:str="/", _:str=Depends(auth)):
    if not path.startswith("/"): raise HTTPException(400,"Absolute path required")
    return await send_node(node_id,{"type":"files","path":path})

@app.get("/api/node/{node_id}/services")
async def services(node_id:int, _:str=Depends(auth)):
    return await send_node(node_id,{"type":"services"})

@app.post("/api/node/{node_id}/power")
async def power(node_id:int, body:dict, _:str=Depends(auth)):
    action=body.get("action")
    if action not in {"start","stop","restart","emergency-stop"}: raise HTTPException(400,"Invalid action")
    result=await send_node(node_id,{"type":"power","action":action},30); log("node.power",str(node_id),action); return result

@app.post("/api/node/{node_id}/vps")
async def create_vps(node_id:int, body:dict, _:str=Depends(auth)):
    result=await send_node(node_id,{"type":"vps_create","name":str(body.get("name",""))},60)
    c=db(); c.execute("INSERT INTO vps(name,node_id,kind) VALUES(?,?,?)",(body.get("name","vps"),node_id,"libvirt")); c.commit(); c.close(); return result

@app.get("/api/node/{node_id}/vps")
async def list_vps(node_id:int, _:str=Depends(auth)):
    return await send_node(node_id,{"type":"vps_list"})

@app.post("/api/vps/{name}/action")
async def vps_action(name:str, body:dict, _:str=Depends(auth)):
    action=body.get("action")
    if action not in {"start","stop","restart","emergency-stop"}: raise HTTPException(400,"Invalid action")
    c=db(); v=c.execute("SELECT * FROM vps WHERE name=?",(name,)).fetchone(); c.close()
    if not v: raise HTTPException(404,"VPS not found")
    result=await send_node(v["node_id"],{"type":"vps_action","name":name,"action":action},30); log("vps.power",name,action); return result

@app.websocket("/ws/agent/{token}")
async def agent(ws:WebSocket, token:str):
    c=db(); n=c.execute("SELECT * FROM nodes WHERE token=?",(token,)).fetchone(); c.close()
    if not n: await ws.close(code=1008); return
    await ws.accept(); node_id=n["id"]; connections[node_id]=ws
    try:
        while True:
            msg=json.loads(await ws.receive_text())
            if msg.get("reply_to") in pending:
                if not pending[msg["reply_to"]].done(): pending[msg["reply_to"]].set_result(msg.get("data",msg))
                continue
            if msg.get("type")=="heartbeat":
                info=msg.get("info",{}); c=db(); c.execute("UPDATE nodes SET info=?,status='online',last_seen=? WHERE id=?",(json.dumps(info),int(time.time()),node_id)); c.commit(); c.close()
    except WebSocketDisconnect: pass
    except Exception: pass
    finally:
        if connections.get(node_id) is ws: connections.pop(node_id,None)
        c=db(); c.execute("UPDATE nodes SET status='offline' WHERE id=?",(node_id,)); c.commit(); c.close()
