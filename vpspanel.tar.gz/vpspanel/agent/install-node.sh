#!/usr/bin/env bash
set -e
PANEL=""
TOKEN=""
while [ $# -gt 0 ]; do case "$1" in --panel) PANEL="$2"; shift 2;; --token) TOKEN="$2"; shift 2;; *) shift;; esac; done
[ -n "$PANEL" ] || { echo "missing --panel"; exit 1; }
[ -n "$TOKEN" ] || { echo "missing --token"; exit 1; }
apt-get update -y
apt-get install -y python3 python3-venv curl
mkdir -p /opt/vpspanel-agent
cp /dev/null /opt/vpspanel-agent/.env
python3 -m venv /opt/vpspanel-agent/venv
/opt/vpspanel-agent/venv/bin/pip install -q websockets==15.0.1
curl -fsSL "$PANEL/static/agent.py" -o /opt/vpspanel-agent/agent.py
cat > /opt/vpspanel-agent/.env <<EOF
PANEL_URL=$PANEL
NODE_TOKEN=$TOKEN
EOF
cat > /etc/systemd/system/vpspanel-agent.service <<EOF
[Unit]
Description=VPS Panel Node Agent
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
EnvironmentFile=/opt/vpspanel-agent/.env
ExecStart=/opt/vpspanel-agent/venv/bin/python /opt/vpspanel-agent/agent.py
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now vpspanel-agent
systemctl --no-pager status vpspanel-agent || true
