import asyncio, json, os, platform, shutil, socket, subprocess, sys, time
from pathlib import Path
import websockets

PANEL=os.getenv("PANEL_URL","http://127.0.0.1:8000").rstrip("/")
TOKEN=os.getenv("NODE_TOKEN","")
WS=PANEL.replace("https://","wss://").replace("http://","ws://")+"/ws/agent/"+TOKEN

async def run(cmd, timeout=60):
    p=await asyncio.create_subprocess_shell(cmd,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT)
    try: out,_=await asyncio.wait_for(p.communicate(),timeout)
    except asyncio.TimeoutError: p.kill(); return "command timed out"
    return out.decode(errors="replace")

def info():
    mem=shutil.disk_usage("/")
    try:
        with open("/proc/meminfo") as f: m={x.split(":")[0]:int(x.split()[1]) for x in f if ":" in x}
        ram_total=m.get("MemTotal",0)*1024; ram_avail=m.get("MemAvailable",0)*1024
    except: ram_total=ram_avail=0
    try: virt=subprocess.check_output(["systemd-detect-virt"],text=True,stderr=subprocess.DEVNULL).strip()
    except: virt="unknown"
    return {"hostname":socket.gethostname(),"os":platform.platform(),"kernel":platform.release(),"arch":platform.machine(),"cpu":os.cpu_count() or 1,"ram_total":ram_total,"ram_used":max(0,ram_total-ram_avail),"disk_total":mem.total,"disk_used":mem.used,"virt":virt,"uptime":int(time.time()-float(Path('/proc/uptime').read_text().split()[0])),"libvirt":shutil.which("virsh") is not None}

async def reply(ws,rid,data): await ws.send(json.dumps({"reply_to":rid,"data":data}))

async def handle(ws,msg):
    rid=msg.get("id"); typ=msg.get("type")
    if typ=="shell": return await reply(ws,rid,{"output":await run(msg.get("command",""))})
    if typ=="files":
        p=Path(msg.get("path","/")).resolve()
        try:
            items=[]
            for x in sorted(p.iterdir(),key=lambda z:(not z.is_dir(),z.name.lower())):
                try: size=x.stat().st_size
                except: size=0
                items.append({"name":x.name,"dir":x.is_dir(),"size":size})
            return await reply(ws,rid,{"path":str(p),"items":items})
        except Exception as e: return await reply(ws,rid,{"error":str(e)})
    if typ=="services": return await reply(ws,rid,{"output":await run("systemctl list-units --type=service --no-pager --no-legend | head -100")})
    if typ=="power":
        a=msg.get("action")
        cmd={"restart":"systemctl reboot","stop":"systemctl poweroff","emergency-stop":"systemctl poweroff"}.get(a)
        if not cmd: return await reply(ws,rid,{"error":"start is not supported for the current node"})
        asyncio.create_task(run(cmd,10)); return await reply(ws,rid,{"ok":True,"message":a})
    if typ=="vps_list":
        if not shutil.which("virsh"): return await reply(ws,rid,{"error":"libvirt is not available"})
        return await reply(ws,rid,{"output":await run("virsh list --all")})
    if typ=="vps_action":
        if not shutil.which("virsh"): return await reply(ws,rid,{"error":"libvirt is not available"})
        name=msg.get("name"); a=msg.get("action"); sub={"start":"start","stop":"shutdown","restart":"reboot","emergency-stop":"destroy"}.get(a)
        if not sub: return await reply(ws,rid,{"error":"invalid action"})
        return await reply(ws,rid,{"output":await run(f"virsh {sub} {__import__('shlex').quote(name)}")})
    if typ=="vps_create": return await reply(ws,rid,{"error":"VPS creation requires an image/network/storage profile and is not enabled by default"})
    return await reply(ws,rid,{"error":"unknown command"})

async def main():
    if not TOKEN: raise SystemExit("NODE_TOKEN is required")
    while True:
        try:
            async with websockets.connect(WS,ping_interval=20,ping_timeout=20,max_size=10_000_000) as ws:
                while True:
                    await ws.send(json.dumps({"type":"heartbeat","info":info()}))
                    try:
                        msg=await asyncio.wait_for(ws.recv(),5)
                        await handle(ws,json.loads(msg))
                    except asyncio.TimeoutError: pass
        except Exception:
            await asyncio.sleep(3)

asyncio.run(main())
