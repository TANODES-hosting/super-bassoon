# VPS Panel

A fast working web VPS panel MVP with a web dashboard, node agent, real heartbeat, terminal, files, services, node power controls, capability detection and optional libvirt VPS controls.

## Panel

```bash
cd panel
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
export PANEL_ADMIN_PASSWORD='replace-this'
export PANEL_ADMIN_TOKEN='replace-this'
uvicorn server:app --host 0.0.0.0 --port 8000
```

Open `http://SERVER:8000` and log in with username `admin` and the password from `PANEL_ADMIN_PASSWORD`.

## Add a node

Create a node in the web panel, copy the generated command, replace `YOUR_PANEL` in the command with the panel address if necessary, and run it as root on the VPS.

The node agent connects outbound over WebSocket, so the node does not need a public IPv4 as long as it can reach the panel.

## Current machine

Your `systemd-detect-virt` result is `kvm`, so the agent will report `kvm`. That means the machine is a KVM guest. It does not automatically mean the guest can create nested KVM VPSs. The panel checks for `virsh` before exposing libvirt operations.

## Security

This is an MVP. Change the default password before exposing it to the internet. Put the panel behind HTTPS and a reverse proxy before production use. Do not expose the panel with the example password.
